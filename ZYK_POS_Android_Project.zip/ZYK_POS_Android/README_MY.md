# ZYK Mobile POS — Android APK project

ဒီ project သည် `Pos_Fixed.html` ကို Android WebView app အဖြစ် ထုပ်ပိုးထားသည်။

## APK ထုတ်ရန် (ဖုန်းမှ GitHub အသုံးပြုနိုင်သည်)
1. ဒီ ZIP ကို ဖြည်ပါ။
2. GitHub တွင် repository အသစ်တစ်ခုဖန်တီးပါ။
3. ZIP ထဲက ဖိုင်/ဖိုလ်ဒါအားလုံးကို repository ၏ root ထဲ upload လုပ်ပြီး `main` branch သို့ commit လုပ်ပါ။
4. Repository → Actions → **Build ZYK POS APK** ကိုဖွင့်ပါ။
5. Build ပြီးပါက workflow run ၏ Artifacts အောက်မှ `ZYK-Mobile-POS-debug` ကို download လုပ်ပါ။
6. ZIP ကိုဖြည်ပြီး `app-debug.apk` ကို Android ဖုန်းတွင် install လုပ်ပါ။ Unknown apps install ခွင့်ကို လိုအပ်ပါက ခွင့်ပြုပါ။

## ပါဝင်သောအရာများ
- Local HTML/CSS/JavaScript WebView app
- JavaScript နှင့် DOM storage ဖွင့်ထားသည် (LocalStorage အသုံးပြုရန်)
- ဖုန်းထဲမှ ဓာတ်ပုံ/JSON ဖိုင်ရွေးနိုင်ရန် file chooser
- Android app ထဲမှ JSON backup ကို app-specific storage တွင်သိမ်းရန် bridge
- Google Sheets ချိတ်ဆက်မှုအတွက် Internet permission

## အရေးကြီး
- ဤနေရာတွင် Android SDK/Gradle build environment မရှိသဖြင့် APK ကို ဒီ runtime ထဲမှာ တိုက်ရိုက် compile မလုပ်နိုင်ပါ။ GitHub Actions workflow က cloud runner ပေါ်တွင် APK ကို build ပေးမည်။
- လက်ရှိ HTML ထဲတွင် Google Sheets sync သည် Apps Script Web App URL နှင့် သက်ဆိုင်ရာ Apps Script deployment လိုအပ်သည်။
- Android backup သည် app-specific storage ထဲတွင်သိမ်းသည်။ ဖုန်းပြောင်းမည်/ app uninstall လုပ်မည်ဆိုလျှင် JSON backup ကို သီးခြားကူးယူထားပါ။
- ဒီ project သည် debug APK ထုတ်ပေးသည်။ Play Store ဖြန့်ချိရန် signed release build ကို သီးခြားပြင်ဆင်ရမည်။
